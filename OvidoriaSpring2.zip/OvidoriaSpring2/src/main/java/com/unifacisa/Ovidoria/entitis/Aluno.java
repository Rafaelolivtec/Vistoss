package com.unifacisa.Ovidoria.entitis;

import jakarta.persistence.Entity;

@Entity
public class Aluno extends Pessoa {

	public Aluno() {

	}

	public Aluno(String nome, String email, String senha) {
		super(nome, email, senha);
	}

}
