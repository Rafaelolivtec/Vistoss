package com.unifacisa.Ovidoria.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.unifacisa.Ovidoria.entitis.Ocorrencia;
import com.unifacisa.Ovidoria.entitis.Pessoa;
import com.unifacisa.Ovidoria.repositories.OcorrenciaMongoRepositorio;

@Service
public class OcorrenciaServices {
	@Autowired
	OcorrenciaMongoRepositorio MongoRepositorio;

	public Boolean Adicionar(String tipo, String ocorrencia, Pessoa pessoa) {
		Ocorrencia oco = new Ocorrencia(tipo, ocorrencia, pessoa);
		MongoRepositorio.save(oco);
		return true;
	}

	public Boolean apagar(Long id) {
		MongoRepositorio.deleteById(id);
		return true;
	}

	public Boolean apagarTudo() {
		MongoRepositorio.deleteAll();
		return true;
	}

	public void lista() {
		for (Ocorrencia o : MongoRepositorio.findAll()) {
			if (o != null) {
				System.out.println(o);
			} else {
				System.out.println("NAO EXITEM OCORRENCIAS CADASTRADAS!");
			}

		}
	}
}
