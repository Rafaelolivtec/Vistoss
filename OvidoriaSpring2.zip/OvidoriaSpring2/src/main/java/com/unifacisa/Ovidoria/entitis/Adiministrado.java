package com.unifacisa.Ovidoria.entitis;

import jakarta.persistence.Entity;

@Entity
public class Adiministrado extends Pessoa {

	public Adiministrado() {

	}

	public Adiministrado(String nome, String email, String senha) {
		super(nome, email, senha);
		this.setadm(true);
	}

}
