package com.unifacisa.Ovidoria;

import java.util.Scanner;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.unifacisa.Ovidoria.entitis.Pessoa;
import com.unifacisa.Ovidoria.services.OcorrenciaServices;
import com.unifacisa.Ovidoria.services.PessoaService;

@SpringBootApplication
public class OvidoriaApplication implements CommandLineRunner {

	@Autowired
	PessoaService pessoaService;

	@Autowired
	OcorrenciaServices ocorrenciaService;

	public static void main(String[] args) {

		SpringApplication.run(OvidoriaApplication.class, args);

	}

	@Override
	public void run(String... args) throws Exception {
		Scanner sc = new Scanner(System.in);

		pessoaService.AdicionarAdm("JACKSON", "ADM", "ADM");

		int ops = 0;
		while (ops != 3) {

			System.out.println("****************************************************");
			System.out.println("*  BEM VINDO AO SISTEMA DE OUVIDORIA DA UNIFACISA  *");
			System.out.println("****************************************************");
			System.out.println("*                  [1] CADASTRA-SE                 *");
			System.out.println("*                  [2] LOGAR                       *");
			System.out.println("*                  [3] SAIR                        *");
			System.out.println("****************************************************");

			System.out.print("DIGITE A OPCAO DESEJADA: ");
			ops = sc.nextInt();

			switch (ops) {
			/*
			 * CADASTRA USUARIO
			 */
			case 1: {

				System.out.print("\nPOR FAVOR, DIGITE O SEU NOME: ");
				String nome = sc.next().toUpperCase();
				System.out.print("\nINFORME O SEU EMAIL: ");
				String email = sc.next().toUpperCase();

				System.out.print("\nAGORA BASTA DIGITAR UMA SENHA FORTE: ");
				String senha = sc.next().toUpperCase();

				pessoaService.Adicionar(nome, email, senha);

				break;
			}
			/*
			 * LOGAR
			 */
			case 2: {

				System.out.println("\nOLA, TUDO BEM?\nESPERO QUE SIM.\n");
				System.out.print("POR FAVOR INFORME SEU EMAIL: ");
				String email = sc.next().toUpperCase();
				System.out.print("\nAGORA BASTA DIGITAR SUA SENHA: ");
				String senha = sc.next().toUpperCase();

				Pessoa usuarioLogado = pessoaService.logar(email, senha);

				if (usuarioLogado != null) {
					int opsUsuario = 0;
					while (opsUsuario != 5) {

						System.out.println("****************************************************");
						System.out.println("*                SEJA BEM VINDO!                   *");
						System.out.println("****************************************************");
						System.out.println("*          [1] CADASTRA MANIFESTACAO               *");
						System.out.println("*          [2] VER MANIFESTACOES                   *");
						System.out.println("*          [3] APAGAR MANIFESTACAO                 *");
						System.out.println("*          [4] APAGAR TODAS AS MANIFESTACOES       *");
						System.out.println("*          [5] SAIR                                *");
						System.out.println("****************************************************");

						System.out.print("DIGITE A OPCAO DESEJADA: ");
						opsUsuario = sc.nextInt();
						switch (opsUsuario) {
						/*
						 * CADASTRA OCORRENCIA
						 */
						case 1: {
							if (usuarioLogado.getadm()) {
								System.err.println("USUARIO NAO TEM PERMICAO PARA CADASTRA OCORRENCIAS!\n");
							} else {

								System.out.print("\nQUAL O TIPO DA SUA MANIFESTACAO: ");
								String tipo = sc.next().toUpperCase();

								System.out.println("AGORA BASTA DIGITAR SUA MANIFESTACAO: ");
								String ocorrencia = sc.next().toUpperCase();

								ocorrenciaService.Adicionar(tipo, ocorrencia, usuarioLogado);

							}

							break;
						}
						/*
						 * LISTAR
						 */
						case 2: {

							ocorrenciaService.lista();

							break;
						}
						/*
						 * APAGAR
						 */
						case 3: {
							ocorrenciaService.lista();
							System.out.println("DIGITE O ID DA MANIFESTACAO PARA APAGA.");
							long id = sc.nextLong();
							ocorrenciaService.apagar(id);

							break;
						}
						/*
						 * APAGAR TUDO
						 */
						case 4: {
							ocorrenciaService.apagarTudo();
							break;
						}
						}
					}
				} else {
					System.err.println("E-MAIL OU SENHA INVALIDO(A)\nPOR FAVOR TENTE NOVAMENTE.");
				}

			}
			}

		}
		sc.close();
	}

}
