package com.unifacisa.Ovidoria.repositories;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.unifacisa.Ovidoria.entitis.Pessoa;

public interface PessoaMongoRepositorio extends MongoRepository<Pessoa, Integer> {

}
