package com.unifacisa.Ovidoria.repositories;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.unifacisa.Ovidoria.entitis.Ocorrencia;

public interface OcorrenciaMongoRepositorio extends MongoRepository<Ocorrencia, Long> {

}
