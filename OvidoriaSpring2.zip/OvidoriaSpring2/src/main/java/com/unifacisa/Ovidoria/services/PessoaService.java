package com.unifacisa.Ovidoria.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.unifacisa.Ovidoria.entitis.Adiministrado;
import com.unifacisa.Ovidoria.entitis.Aluno;
import com.unifacisa.Ovidoria.entitis.Pessoa;
import com.unifacisa.Ovidoria.repositories.PessoaMongoRepositorio;

@Service
public class PessoaService {

	@Autowired
	PessoaMongoRepositorio pessoaMongoRepositorio;

	public Boolean Adicionar(String name, String email, String senha) {
		Aluno a = new Aluno(name, email, email);
		pessoaMongoRepositorio.save(a);
		return true;
	}

	public Boolean AdicionarAdm(String name, String email, String senha) {
		Adiministrado a = new Adiministrado(name, email, email);
		pessoaMongoRepositorio.save(a);
		return true;
	}

	public Pessoa logar(String email, String senha) {
		for (Pessoa pessoa : pessoaMongoRepositorio.findAll()) {
			if ((pessoa.getEmail().equals(email)) && (pessoa.getSenha().equals(senha))) {
				return pessoa;
			}
		}
		return null;
	}
}
